angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('page1.cameraTabDefaultPage', {
    url: '/page2',
    views: {
      'tab1': {
        templateUrl: 'templates/cameraTabDefaultPage.html',
        controller: 'cameraTabDefaultPageCtrl'
      }
    }
  })

  .state('page1.cartTabDefaultPage', {
    url: '/page3',
    views: {
      'tab2': {
        templateUrl: 'templates/cartTabDefaultPage.html',
        controller: 'cartTabDefaultPageCtrl'
      }
    }
  })

  .state('page1', {
    url: '/page1',
    templateUrl: 'templates/page1.html',
    abstract:true
  })

  .state('home', {
    url: '/page5',
    templateUrl: 'templates/home.html',
    controller: 'homeCtrl'
  })

  .state('buscarPratos', {
    url: '/page7',
    templateUrl: 'templates/buscarPratos.html',
    controller: 'buscarPratosCtrl'
  })

  .state('perfilDoCliente', {
    url: '/page8',
    templateUrl: 'templates/perfilDoCliente.html',
    controller: 'perfilDoClienteCtrl'
  })

$urlRouterProvider.otherwise('/page1/page2')


});